<div class="container-fluid contact-page">
           <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    
                    <div class="dashboard-section">
                         
                        <h1>Contact <span class="orange-text">Us</span></h1>
                        <p>If you would like support or if you would like to contact us feel free to contact us here, we are always ready to take your enquiry.</p>
						<p><span class="text20 orange-text">We offer 24/7 support,</span> if you would like to get instant chat support you can hit the bottom right of this screen and see if we have a little monster ready to chat away! </p>
                        <hr>
						<p align="center"><span class="text20">Have a great day from all us here at the call monster team.</span></p>
                       <hr>
                      <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p><strong>Contact Us Form</strong></p>
                          <input  type="text" value="" placeholder="Name">
                          <input  type="text" value="" placeholder="Email">
                          <input  type="search" value="" placeholder="Phone">
                          <input  type="search" value="" placeholder="Subject">                            
                          <textarea name="msg" rows="6" placeholder="Your Message"></textarea>
                          <a href="#" class="dashboard-btn">Send Message</a>
                      </div>
                             
                     </div> 
                     
                    </div>
                </div>
            </div>     
     </div> 
     
     </div>