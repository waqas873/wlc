<?php


namespace Twilio\Exceptions;


class DeserializeException extends TwilioException {

}